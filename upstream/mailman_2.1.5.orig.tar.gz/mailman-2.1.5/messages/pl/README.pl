Projekt polonizacji Mailmana rozpocz�� si� w kwietniu 2001. 

Oficjaln� stron� t�umaczenia jest:
http://linux.gda.pl/pub/Mailman-pl/

Lista dyskusyjna polskich t�umaczy:
http://linux.gda.pl/mailman/listinfo/mailman-pl


Do tej pory udzia� w t�umaczeniu wzieli (w kolejno�ci chronologicznej
przy��czania si� do projektu):
- Marcin Sochacki <wanted%linux.gda.pl>
- Pawe� Ko�odziejczyk <Pawel.Kolodziejczyk%comarch.pl>
- Marcin Zaborowski <m.zaborowski%il.pw.edu.pl>
- Wojciech Czarnowski <wojtekcz%rodos.com.pl>
- Bartosz Sawicki <sawickib%iem.pw.edu.pl>
- Robert �wi�cki <rswieck1%elka.pw.edu.pl>


W chwili obecnej przet�umaczone jest 99% interfejsu subskrybenta i oko�o 
85% interfejsu administracyjnego. Najbardziej aktualnej wersji szukajcie w
oficjalnych CVS Mailmana. 

Do zrobienia:
- szlifowanie, polerowanie :)
- sko�czenie t�umaczenia mailman.po (zosta�o jeszcze 297 msgid)
- przet�umaczenie README.* dla r�nych MTA

Od jakiego� roku nad t�umaczeniem pracuj� wla�ciwie tylko sam, ale bardzo
ch�tnie przyjm� wszystkie formy pomocy.

2003-12-30, Bartosz Sawicki <sawickib@iem.pw.edu.pl


