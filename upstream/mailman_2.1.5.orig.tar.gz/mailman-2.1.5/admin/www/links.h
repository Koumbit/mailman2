<!-- -*- html -*- -->
<h3>Overview</h3>
<li><a href="index.html">Home</a>
<li><a href="features.html">Features</a>
<li><a href="i18n.html">Internationalization</a>
<li><a href="otherstuff.html">Rants, Papers, and Logos</a>
<li><a href="inthenews.html">Mailman in Use</a>
<li><a href="prev.html">Previous Releases</a>
<li><a href="bugs.html">Bugs and Patches</a>
<li><a href="mirrors.html">Mirrors</a>
